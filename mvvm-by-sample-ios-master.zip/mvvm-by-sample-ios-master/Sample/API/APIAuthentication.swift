//
//  APIAuthentication.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/3/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation
import SwiftyJSON

class APIAuthentication: APIBase {

    func authorizeWithEmail(email: String, andPassword password: String,
                            success: ((result: JSON) -> Void), failure: (error: APIError) -> Void,
                            completion: () -> Void) {

        //TODO: check sample email hard coded
        get(
            APIPaths.authenticationUrl,
            params: nil,
            success: success,
            failure: failure,
            completion: completion
        )
    }
}