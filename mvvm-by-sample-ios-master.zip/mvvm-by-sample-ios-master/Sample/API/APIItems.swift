//
//  APIItems.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/5/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation
import SwiftyJSON

class APIItems: APIBase {

    func items(success: ((result: [Item]) -> Void), failure: (error: APIError) -> Void,
                completion: () -> Void) {


        get(
            APIPaths.itemsUrl,
            params: nil,
            success: { json in
                let items: [Item] = json.ext_transformJsonArray()
                success(result: items)
            },
            failure: failure,
            completion: completion
        )
    }
}
