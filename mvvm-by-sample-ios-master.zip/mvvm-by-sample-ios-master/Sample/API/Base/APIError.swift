//
//  APIError.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/3/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation

struct APIError {
    var code: Int = Int.max
    var requestBody: AnyObject?
    var simpleDescription: String {
        switch code {
        case 400:
            return "Invalid Request"
        case 401:
            return "Invalid Access Token"
        default:
            return "Unknown Error"
        }
    }

    init() {}

    init(code: Int) {
        self.code = code
    }

    init(code: Int, requestBody: AnyObject?) {
        self.init(code: code)
        self.requestBody = requestBody
    }
}