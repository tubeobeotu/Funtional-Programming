//
//  APIPaths.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/3/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation

struct APIPaths {

    static var baseUrl = "https://gist.githubusercontent.com/fernandodev/"

    static var authenticationUrl = baseUrl + "7e5272c29b18a191c221d4f2c72aae68/raw/07cb8dd69e41f0ac23c5d5cf0bb86be0edab5c7e/login.json"
    static var itemsUrl = baseUrl + "4548bdd94a14fa8bb8aad6648b03e750/raw/87bdb3a2354ce0f5df7e075ecadd517f9039c829/items.json"
}