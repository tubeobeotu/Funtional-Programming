//
//  APIBase.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/3/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Alamofire
import SwiftyJSON

class APIBase {
    private weak var context: UIViewController?
    private var headers: [String:String] = [:]

    convenience init(controller: UIViewController) {
        self.init()
        context = controller
    }

    //MARK: HTTP Methods
    func get(url: String, params: [String:AnyObject]?, success: ((result: JSON) -> Void), failure: (error: APIError) -> Void, completion: () -> Void) {

        Alamofire.request(.GET, url, parameters: params, headers: headers).responseJSON { response in
            self.handleResponse(response, success: success, failure: failure, completion: completion)
        }
    }

    private func handleResponse(response: Response<AnyObject, NSError>, success: ((result: JSON) -> Void), failure: (error: APIError) -> Void, completion: () -> Void) {

        switch response.result {
        case .Success:
            if let body = response.response {
                if let json = response.result.value where body.statusCode >= 200 && body.statusCode < 300 {
                    success(result: JSON(json))
                } else {
                    handleErrors(
                        APIError(code: body.statusCode, requestBody: response.result.value),
                        failureCallback: failure
                    )
                }
            } else {
                handleErrors(
                    APIError(),
                    failureCallback: failure
                )
            }
            break
        case .Failure:
            let code = response.response?.statusCode ?? Int.max
            
            handleErrors(
                APIError(code: code),
                failureCallback: failure
            )
            break
        }
        completion()
    }

    private func handleErrors(error: APIError, failureCallback failure: (error: APIError) -> Void) {
        if let controller = context where error.code == 401 {
            LoginViewController.presentLoginViewController(fromViewController: controller, animated: true)
        }

        failure(error: error)
    }
}