//
//  ItemViewModel.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/5/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation
import UIKit

struct ItemViewModel: ItemViewPresentable {
    var item: Item

    init(item: Item) {
        self.item = item
    }
}

//MARK: Item Image Presentable
extension ItemViewModel {
    var imageURL: NSURL? { return item.thumbURL }
}

//MARK: Item Label Presentable
extension ItemViewModel {
    var text: String { return item.name }
    var textColor: UIColor { return UIColor.whiteColor() }
}