//
//  LoginFormViewModel.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/4/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import SVProgressHUD

struct LoginFormViewModel: LoginFormPresentable {
    let api = APIAuthentication()

    private var errors: [String] = []
    private weak var context: UIViewController?

    init(controller: UIViewController) {
        context = controller
    }

    //MARK: Error Checking
    mutating func cleanErrors() {
        errors.removeAll()
    }

    mutating func checkEmailErrors(email: String) -> Bool {
        let regex = "[A-Z0-9a-z._%+-]+@[A-Za-z0-9.-]+\\.[A-Za-z]{2,4}"
        let validator = NSPredicate(format: "SELF MATCHES %@", regex)
        let valid = validator.evaluateWithObject(email);

        if !valid {
            errors.append("Este endereço de e-mail aparenta não ser válido")
        }

        return valid
    }

    mutating func checkPasswordErrors(password: String) -> Bool {
        let valid = !password.isEmpty && password.characters.count >= 6

        if !valid {
            errors.append("Sua senha precisa ter mais de 6 caracteres")
        }

        return valid
    }

    func showErrors() {
        let message = errors.joinWithSeparator("\n")
        let errorAlert = UIAlertController(title: "Erros", message: message, preferredStyle: .Alert)
        errorAlert.addAction(UIAlertAction(title: "OK", style: .Default, handler: nil))

        context?.presentViewController(errorAlert, animated: true, completion: nil)
    }

    func leftViewForTextField(image: UIImage?) -> UIImageView {
        //5px as padding
        let imageView = UIImageView(frame: CGRectMake(0, 0, 15 + 5, 15))

        imageView.image = image
        imageView.contentMode = .ScaleAspectFit

        return imageView
    }
}

//MARK: Email Presentable
extension LoginFormViewModel {
    var emailPlaceholder: String { return "seu@email.com" }
    var emailLeftView: UIView {
        return leftViewForTextField(UIImage(named: "icn-textfield-email"))
    }
    var emailLeftViewMode: UITextFieldViewMode { return .Always }
}

//MARK: Password Presentable
extension LoginFormViewModel {
    var passwordPlaceholder: String { return "senha" }
    var passwordLeftView: UIView {
        return leftViewForTextField(UIImage(named: "icn-textfield-password"))
    }
    var passwordLeftViewMode: UITextFieldViewMode { return .Always }
}

//MARK: Login Text Field Presentable
extension LoginFormViewModel {
    var textColor: UIColor { return UIColor.whiteColor() }
    var placeholderTextColor: UIColor { return UIColor(white: 0.85, alpha: 1) }
    var borderStyle: UITextBorderStyle { return .None }
    var bottomBorderColor: UIColor { return UIColor.whiteColor() }
    var bottomBorderWidth: CGFloat { return 1 }
}

//MARK: Login Button Presentable
extension LoginFormViewModel {

    mutating func login(email: String, password: String) {
        cleanErrors()

        let validEmail = checkEmailErrors(email)
        let validPassword = checkPasswordErrors(password)

        if !validEmail || !validPassword {
            showErrors()
            return
        }

        //Start loading
        SVProgressHUD.showWithStatus("Aguarde ...")
        api.authorizeWithEmail(
            email,
            andPassword: password,
            success: { json in
                Account.setDefaultAccountId(json["moipAccountId"].string ?? "")
                Account.setDefaultAccountAccessToken(json["access_token"].string)
                self.context?.dismissViewControllerAnimated(true, completion: nil)
            },
            failure: { error in
                self.errors.append("Email ou senha inválidos")
                self.showErrors()
            },
            completion: {
                SVProgressHUD.dismiss()
            }
        )
    }
}