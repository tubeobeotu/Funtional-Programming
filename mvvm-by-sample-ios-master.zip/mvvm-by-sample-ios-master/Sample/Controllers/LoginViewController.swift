//
//  LoginViewController.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/4/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation
import UIKit

class LoginViewController: UIViewController {
    @IBOutlet weak var loginFormView: LoginFormView!

    override func viewDidLoad() {
        super.viewDidLoad()
        setupViews()

        view.addGestureRecognizer(UITapGestureRecognizer(target: self, action: #selector(dismissKeyboard)))
    }

    //MARK: Setup Views
    func setupViews() {
        loginFormView.configure(withPresenter: LoginFormViewModel(controller: self))
    }

    func dismissKeyboard() {
        //Causes the view (or one of its embedded text fields) to resign the first responder status.
        view.endEditing(true)
    }

    static func presentLoginViewController(fromViewController viewController: UIViewController, animated: Bool, completion: (() -> Void)? = nil) {

        let nav = UIStoryboard(name: "Authentication", bundle: nil).instantiateViewControllerWithIdentifier("NavigationLoginViewController")
        viewController.presentViewController(nav, animated: animated, completion: completion)
    }
}
