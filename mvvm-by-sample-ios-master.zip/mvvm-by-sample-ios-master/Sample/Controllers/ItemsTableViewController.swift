//
//  SalesTableViewController.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/4/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation
import UIKit
import SVProgressHUD

class ItemsTableViewController: UITableViewController {

    var api: APIItems!
    var items: [Item] = []

    override func viewDidLoad() {
        super.viewDidLoad()

        api = APIItems(controller: self)
        refreshControl = UIRefreshControl()
        refreshControl?.addTarget(self, action: #selector(refresh), forControlEvents: .ValueChanged)
        refreshControl?.bringSubviewToFront(tableView)
    }

    override func viewDidAppear(animated: Bool) {
        super.viewDidAppear(animated)

        if !Account.defaultAccount.isLoggedIn {
            LoginViewController.presentLoginViewController(fromViewController: self, animated: true)
        } else {
            refreshControl?.beginRefreshingManually()
            refresh()
        }
    }

    //MARK: Api
    func refresh() {
        refreshControl?.beginRefreshing()
        api.items(
            { result in
                self.items = result
                self.tableView.reloadData()
            },
            failure: { error in
                if error.code != 401 {
                    SVProgressHUD.showErrorWithStatus("Can't load items :(")
                }
            },
            completion: {
                self.refreshControl?.endRefreshing()
            }
        )
    }
}

//MARK: Data Source
extension ItemsTableViewController {
    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return section == 0 ? items.count : 0
    }

    override func tableView(tableView: UITableView, heightForRowAtIndexPath indexPath: NSIndexPath) -> CGFloat {
        return indexPath.section == 0 ? 180 : 0
    }

    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCellWithIdentifier("ItemCell") as! ItemViewCell

        let item = items[indexPath.row]
        cell.configure(withPresenter: ItemViewModel(item: item))
        
        return cell
    }
}
