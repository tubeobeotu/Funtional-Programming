//
//  Item.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/5/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation
import SwiftyJSON

struct Item: JSONDeserialization {
    var name: String
    var thumb: String
    var thumbURL: NSURL?
    var description: String

    init(json: JSON) {
        name = json["name"].string ?? ""
        thumb = json["thumb"].string ?? ""
        thumbURL = NSURL(string: thumb)
        description = json["description"].string ?? ""
    }
}
