//
//  Account.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/4/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import SwiftyJSON

struct Account {
    static var defaultAccount: Account {
        return Account(
            id: NSUserDefaults.standardUserDefaults().stringForKey("user.account_id") ?? "",
            accessToken: NSUserDefaults.standardUserDefaults().stringForKey("user.access_token")
        )
    }

    var id: String
    var accessToken: String?
    var isLoggedIn: Bool { return accessToken != nil }

    init(id: String, accessToken: String?) {
        self.id = id
        self.accessToken = accessToken
    }

    //Just to avoid a better interface for handling multiuser credential storage
    static func setDefaultAccountId(id: String) {
        NSUserDefaults.standardUserDefaults().setValue(id, forKey: "user.account_id")
    }

    static func setDefaultAccountAccessToken(accessToken: String?) {
        NSUserDefaults.standardUserDefaults().setValue(accessToken, forKey: "user.access_token")
    }
}
