//
//  ItemViewCell.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/5/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation
import UIKit

typealias ItemViewPresentable = protocol<ItemImagePresentable, ItemNamePresentable>

class ItemViewCell: UITableViewCell {

    @IBOutlet weak var backgroundImage: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!

    private var delegate: ItemViewPresentable?

    func configure(withPresenter presenter: ItemViewPresentable) {
        delegate = presenter

        if let url = presenter.imageURL {
            backgroundImage.setImage(withURL: url)
        }

        nameLabel.textColor = presenter.textColor
        nameLabel.text = presenter.text
    }
}
