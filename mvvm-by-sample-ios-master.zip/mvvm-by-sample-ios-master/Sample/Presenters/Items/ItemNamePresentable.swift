//
//  ItemNamePresentable.swift
//  Sample
//
//  Created by Fernando Martinez on 7/8/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import UIKit
import Foundation

protocol ItemNamePresentable {
    var text: String { get }
    var textColor: UIColor { get }
}