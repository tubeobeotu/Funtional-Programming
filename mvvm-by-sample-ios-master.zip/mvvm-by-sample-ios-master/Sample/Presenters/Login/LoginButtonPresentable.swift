//
//  LoginButtonPresentable.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/4/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

protocol LoginButtonPresentable {

    mutating func login(email: String, password: String)
}