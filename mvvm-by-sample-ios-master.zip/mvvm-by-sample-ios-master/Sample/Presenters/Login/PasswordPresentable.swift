//
//  PasswordPresentable.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/4/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import Foundation

import UIKit

protocol PasswordPresentable {
    var passwordPlaceholder: String { get }
    var passwordLeftView: UIView { get }
    var passwordLeftViewMode: UITextFieldViewMode { get }
}