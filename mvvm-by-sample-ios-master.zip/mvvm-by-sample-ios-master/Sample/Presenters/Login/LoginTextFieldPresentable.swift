//
//  LoginTextFieldPresentable.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/4/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import UIKit

protocol LoginTextFieldPresentable {
    var textColor: UIColor { get }
    var placeholderTextColor: UIColor { get }
    var borderStyle: UITextBorderStyle { get }
    var bottomBorderColor: UIColor { get }
    var bottomBorderWidth: CGFloat { get }
}