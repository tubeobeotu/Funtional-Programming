//
//  EmailPresentable.swift
//  mvvm-sample
//
//  Created by Fernando Martinez on 5/4/16.
//  Copyright © 2016 fernandodev. All rights reserved.
//

import UIKit

protocol EmailPresentable {
    var emailPlaceholder: String { get }
    var emailLeftView: UIView { get }
    var emailLeftViewMode: UITextFieldViewMode { get }
}
