![](https://www.devexpress.com/Products/NET/Controls/WPF/i/features/mvvm-light.png)

MVVM Simple Sample
==

This project show a way to apply MVVM pattern into an iOS project.

A choose a small sample with fake authentication process and a simple list for some items.

It's a piece of a presentation
MVVM by Sample @fernandodev

BTW, open for discussions. It was my first try applying that architecture.

## Start

You must have cocoapods

```
pod install
open Sample.xcworkspace
```

## Presentation

[All slides are in that repository](https://github.com/fernandodev/mvvm-by-sample-ios/tree/master/Presentation/MVVM).

## LICENSE

MIT 2.0
